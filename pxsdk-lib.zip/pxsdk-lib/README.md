# pixalate-android-sdk

Impression reporting library for android apps, by Pixalate, Inc.
